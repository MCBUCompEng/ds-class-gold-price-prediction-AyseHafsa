
import re
import numpy as np
import pandas as pd


TURKISH_MONTHS = {
    "Ocak": 1,  "Şubat": 2,  "Mart": 3,     "Nisan": 4,
    "Mayıs": 5, "Haziran": 6, "Temmuz": 7,  "Ağustos": 8,
    "Eylül": 9, "Ekim": 10,  "Kasım": 11,  "Aralık": 12,
}


def _parse_turkish_date(date_str: str) -> pd.Timestamp:
    """
    Convert a Turkish-language date string to a pandas Timestamp.

    Examples
    --------
    '29 Mart 2021'  →  Timestamp('2021-03-29')
    '1 Nisan 2021'  →  Timestamp('2021-04-01')
    """
    parts = date_str.strip().split()
    if len(parts) != 3:
        return pd.NaT
    day, month_name, year = parts
    month = TURKISH_MONTHS.get(month_name)
    if month is None:
        return pd.NaT
    return pd.Timestamp(year=int(year), month=month, day=int(day))


def _parse_price(value) -> float:
  
    s = str(value).strip()
   
    dots  = s.count('.')
    commas = s.count(',')

    if commas == 1 and dots >= 1:
       
        s = s.replace('.', '').replace(',', '.')
    elif commas == 0 and dots == 1:
       
        pass  
    elif commas == 0 and dots > 1:
       
        s = s.replace('.', '')
   

    try:
        return float(s)
    except ValueError:
        return np.nan



def load_and_preprocess_data(filepath: str):
   
   
    df = pd.read_csv(filepath, sep=';', dtype=str)
    df.columns = ['Date', 'Open', 'Close']

   
    df['Date'] = df['Date'].apply(_parse_turkish_date)
    df.dropna(subset=['Date'], inplace=True)

   
    df['Open']  = df['Open'].apply(_parse_price)
    df['Close'] = df['Close'].apply(_parse_price)

   
    df.dropna(inplace=True)

   
    df.sort_values('Date', inplace=True)
    df.reset_index(drop=True, inplace=True)

    
    df['Lag_1'] = df['Close'].shift(1)
    df['Lag_2'] = df['Close'].shift(2)
    df['Lag_3'] = df['Close'].shift(3)

   
    df['Rolling_Mean_7'] = df['Close'].shift(1).rolling(window=7).mean()
    df['Rolling_Std_7']  = df['Close'].shift(1).rolling(window=7).std()

   
    df['Daily_Return'] = df['Open'] / df['Lag_1'] - 1

   
    df['DayOfWeek'] = df['Date'].dt.dayofweek 
    df['Month']     = df['Date'].dt.month


    df.dropna(inplace=True)
    df.reset_index(drop=True, inplace=True)

   
    feature_names = [
        'Open', 'Lag_1', 'Lag_2', 'Lag_3',
        'Rolling_Mean_7', 'Rolling_Std_7',
        'Daily_Return', 'DayOfWeek', 'Month'
    ]

    X = df[feature_names].values.astype(float)
    y = df['Close'].values.astype(float)

  
    scaler = {
        'mean': X.mean(axis=0),
        'std' : X.std(axis=0)
    }
   
    scaler['std'][scaler['std'] == 0] = 1.0
    X_scaled = (X - scaler['mean']) / scaler['std']

    return X_scaled, y, scaler, feature_names, df




class LinearRegressionOLS:
    """
    Ordinary Least Squares (OLS) Linear Regression.

    Solves  β = (XᵀX)⁻¹ Xᵀy  analytically — no external ML library used.

    Attributes
    ----------
    weights   : np.ndarray  — learned coefficients [bias, w1, w2, ...]
    """

    def __init__(self):
        self.weights = None

    def fit(self, X: np.ndarray, y: np.ndarray):
        """
        Train the model using the Normal Equation.

        Parameters
        ----------
        X : (n_samples, n_features) feature matrix (already scaled)
        y : (n_samples,) target vector
        """
       
        n = X.shape[0]
        X_b = np.hstack([np.ones((n, 1)), X])   

        XtX_inv = np.linalg.pinv(X_b.T @ X_b)
        self.weights = XtX_inv @ X_b.T @ y

    def predict(self, X: np.ndarray) -> np.ndarray:
       
        if self.weights is None:
            raise RuntimeError("Model has not been trained yet. Call fit() first.")
        n = X.shape[0]
        X_b = np.hstack([np.ones((n, 1)), X])
        return X_b @ self.weights


def train_model(X_train: np.ndarray, y_train: np.ndarray) -> LinearRegressionOLS:
   
    model = LinearRegressionOLS()
    model.fit(X_train, y_train)
    return model



def evaluate_model(model: LinearRegressionOLS,
                   X_test: np.ndarray,
                   y_test: np.ndarray) -> dict:
    
    y_pred = model.predict(X_test)

    n = len(y_test)

   
    mse = np.sum((y_test - y_pred) ** 2) / n

   
    rmse = np.sqrt(mse)

   
    ss_res = np.sum((y_test - y_pred) ** 2)
    ss_tot = np.sum((y_test - y_test.mean()) ** 2)
    r2 = 1 - (ss_res / ss_tot) if ss_tot != 0 else 0.0

    return {
        'MSE'        : mse,
        'RMSE'       : rmse,
        'R2'         : r2,
        'predictions': y_pred
    }
