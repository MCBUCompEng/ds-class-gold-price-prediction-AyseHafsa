import numpy as np
import os
import sys

PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, PROJECT_ROOT)

from Model.functions import load_and_preprocess_data, train_model, evaluate_model



TRAIN_RATIO  = 0.80   



def scale_data(X_train: np.ndarray, X_test: np.ndarray):

    mean = X_train.mean(axis=0)
    std  = X_train.std(axis=0)
    std[std == 0] = 1.0   

    X_train_scaled = (X_train - mean) / std
    X_test_scaled  = (X_test  - mean) / std

    return X_train_scaled, X_test_scaled, {'mean': mean, 'std': std}



def main():
    print("=" * 60)
    print("  Gram Gold (TL) — Price Prediction Pipeline")
    print("=" * 60)

    
    print("\n[1/5] Loading and preprocessing data ...")

    
    _, y, _, feature_names, df = load_and_preprocess_data(DATASET_PATH)

   
    X_raw = df[feature_names].values.astype(float)

    print(f"      Dataset shape after feature engineering : {X_raw.shape}")
    print(f"      Date range : {df['Date'].min().date()} → {df['Date'].max().date()}")

    
    print(f"\n[2/5] Splitting data  (train={TRAIN_RATIO*100:.0f}%"
          f" / test={(1-TRAIN_RATIO)*100:.0f}%)  ...")

    split_idx = int(len(X_raw) * TRAIN_RATIO)

    X_train_raw, X_test_raw = X_raw[:split_idx], X_raw[split_idx:]
    y_train,     y_test     = y[:split_idx],      y[split_idx:]

    print(f"      Training samples : {len(X_train_raw)}")
    print(f"      Testing  samples : {len(X_test_raw)}")

   
    print("\n[3/5] Scaling features (StandardScaler, fit on train set) ...")

    X_train, X_test, scaler = scale_data(X_train_raw, X_test_raw)

   
    print("\n[4/5] Training custom OLS Linear Regression model ...")

    model = train_model(X_train, y_train)
    print(f"      Learned {len(model.weights) - 1} feature weights + 1 bias term.")

   
    print("\n[5/5] Evaluating model on test set ...")

    metrics = evaluate_model(model, X_test, y_test)

    print("\n" + "-" * 40)
    print("  Model Performance (Test Set)")
    print("-" * 40)
    print(f"  MSE  : {metrics['MSE']:>12.4f}  (TL²)")
    print(f"  RMSE : {metrics['RMSE']:>12.4f}  (TL)")
    print(f"  R²   : {metrics['R2']:>12.4f}")
    print("-" * 40)

    
    print("\n" + "=" * 60)
    print("  Next-Day Close Price Prediction")
    print("=" * 60)

 
    last_row_raw   = X_raw[-1].reshape(1, -1)
    last_row_scaled = (last_row_raw - scaler['mean']) / scaler['std']

    next_day_price = model.predict(last_row_scaled)[0]
    last_date      = df['Date'].iloc[-1].date()
    last_close     = df['Close'].iloc[-1]

    print(f"\n  Last available date   : {last_date}")
    print(f"  Last closing price    : {last_close:,.2f} TL")
    print(f"\n  Predicted next close  : {next_day_price:,.2f} TL")
    print("=" * 60)


if __name__ == "__main__":
    main()
